﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace Cadastro.Models
{
    public class Pessoa
    {
        [Key]
        public long Id { get; set; }
        public string Nome { get; set; }
        public string Sexo { get; set; }
        public double Altura { get; set; }
        public double Peso { get; set; }
        public DateTime DataNascimento { get; set; }
    }
}